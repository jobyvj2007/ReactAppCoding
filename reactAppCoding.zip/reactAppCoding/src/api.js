import axios from 'axios';
import { fchown } from 'fs';

const client = axios.create({
  baseURL: 'https://polls.apiblueprint.org/',
});

const api = {
  questions: {
    get: () => client.get('/questions').then(response => {
      return sortByDate(response.data);
    })
  },
  choices: {
    vote: (url) => client.post(url)
  },
}

/**
 * Sort by date with ne won bottom
 */
const sortByDate = (data) => {
  return transformDate(data.sort(function(a, b) {
    return new Date(a.published_at).getTime() - new Date(b.published_at).getTime();
  }));
};

/**
 * transfrm date into redable format
 * @param {*} data 
 */
const transformDate = (data)=> {
  return data.map((elm) => {
    elm['published_at'] = new Date(elm.published_at).toUTCString();
    return elm;
  });
};

export default api;
